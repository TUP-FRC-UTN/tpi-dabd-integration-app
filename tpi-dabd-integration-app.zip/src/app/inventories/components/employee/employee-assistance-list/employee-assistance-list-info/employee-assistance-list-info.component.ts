import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-assistance-list-info',
  standalone: true,
  imports: [],
  templateUrl: './employee-assistance-list-info.component.html',
  styleUrl: './employee-assistance-list-info.component.css'
})
export class EmployeeAssistanceListInfoComponent {

}
