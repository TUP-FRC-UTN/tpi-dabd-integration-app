export interface Service {
    id: number;
    name: string;
    enabled: boolean;
}

export interface ServiceRequest {
    name: string;
}