export enum InventoryType {
  RAW_MATERIAL = 'Raw Material', // Materia Prima
  FINISHED_PRODUCT = 'Finished Product' // Producto Terminado
}