export enum DocumentType {
  DNI = 'DNI', // Documento Nacional de Identidad
  PASSPORT = 'PASSPORT', // Pasaporte
  CUIT = 'CUIT',
  CUIL= 'CUIL'
}