export enum EmployeeType {
  Admin = 'ADMIN', // Administrador
  Security = 'SECURITY'
}