export enum StatusType {
  ACTIVE = 'IN_SERVICE', // Activo
  INACTIVE = 'DOWN' // Inactivo
}
