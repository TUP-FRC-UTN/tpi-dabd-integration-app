export enum ServiceType {
  CLEANING = 'Cleaning', // Limpieza
  MAINTENANCE = 'Maintenance', // Mantenimiento
  SECURITY = 'Security' // Seguridad
}