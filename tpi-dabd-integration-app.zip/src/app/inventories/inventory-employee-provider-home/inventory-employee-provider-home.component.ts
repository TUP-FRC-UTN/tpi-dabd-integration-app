import { Component } from '@angular/core';

@Component({
  selector: 'app-inventory-employee-provider-home',
  standalone: true,
  imports: [],
  templateUrl: './inventory-employee-provider-home.component.html',
  styleUrl: './inventory-employee-provider-home.component.scss'
})
export class InventoryEmployeeProviderHomeComponent {

}
