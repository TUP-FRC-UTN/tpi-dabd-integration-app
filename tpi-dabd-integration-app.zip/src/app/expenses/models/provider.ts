export class Provider {
  id: number = 0;
  name: string = '';
  cuil: string = '';
  type: string = '';
}
