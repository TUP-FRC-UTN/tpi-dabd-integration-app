export default class BillType{
    bill_type_id:number=0;

    name:string='';

    description:string='';
}
