export class percentage {

    value: number = 0;
    simbol: string = ""
}
