export default class Category{
    category_id:number = 0;

    description:string='';

    name:string='';

    is_delete:boolean=false;

    is_updatable:boolean=true;
}
