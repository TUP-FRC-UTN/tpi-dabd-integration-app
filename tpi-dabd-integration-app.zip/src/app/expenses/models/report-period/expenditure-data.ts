export interface ExpenditureData{
    totalAmount:number;
    percentage:number;
    average:number;
}