export interface Period {
  month: number;
  year: number;
  state: string;
  id: number;
  startDate: Date;
  endDate: Date;
}
