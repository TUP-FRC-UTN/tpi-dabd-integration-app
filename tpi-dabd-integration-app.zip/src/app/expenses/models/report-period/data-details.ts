export interface DataDetails {
  totalAmount: number;
  average: number;
  count: number;
  minAmount: number;
  maxAmount: number;
  percentage: number;
}
