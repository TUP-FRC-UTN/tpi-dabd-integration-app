export interface SupplierDTO {
  id: number;
  name: string;
  cuil: string;
}
