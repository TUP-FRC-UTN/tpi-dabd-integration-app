import { Component } from '@angular/core';

@Component({
  selector: 'app-expenses-home',
  standalone: true,
  imports: [],
  templateUrl: './expenses-home.component.html',
  styleUrl: './expenses-home.component.scss'
})
export class ExpensesHomeComponent {

}
