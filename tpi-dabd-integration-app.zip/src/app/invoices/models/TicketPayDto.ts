export interface TicketPayDto {
    idTicket: number;
    title: string; 
    description: string; 
    totalPrice: number;
    adminNameWhoApproves: string;
    period: string;
  }
  