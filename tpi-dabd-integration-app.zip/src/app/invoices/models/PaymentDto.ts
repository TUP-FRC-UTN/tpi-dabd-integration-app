export interface PaymentDto {
    id: number;                   // Cambiado de 'ticketNumber'
    receiptUrl: string;
  }