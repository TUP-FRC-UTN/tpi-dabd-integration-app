import { Component } from '@angular/core';

@Component({
  selector: 'app-review-tickets-transfer',
  standalone: true,
  imports: [],
  templateUrl: './review-tickets-transfer.component.html',
  styleUrl: './review-tickets-transfer.component.css'
})
export class ReviewTicketsTransferComponent {

}
