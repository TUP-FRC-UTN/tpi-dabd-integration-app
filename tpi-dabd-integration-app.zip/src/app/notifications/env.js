(function (window) {
  window.env = window.env || {};
  window.env.CONTACTS_API_URL = 'http://localhost:8006';
  window.env.NOTIFICATIONS_API_URL = 'http://localhost:8011';
})(this);
