export class TemplatePatchModel {
    id: number = 0;
    name: string = '';
    body: string = '';
    
  }
  