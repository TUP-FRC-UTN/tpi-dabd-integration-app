export interface TemplateModel {
  id: number;
  name: string;
  body: string;
  active: Boolean;
  
}
