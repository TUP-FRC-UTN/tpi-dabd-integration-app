export interface PageRequest {
    page?: number;
    size?: number;
    sort?: string[];
  }