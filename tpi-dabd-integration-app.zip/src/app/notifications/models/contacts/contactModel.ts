export interface ContactModel {
  id: number
  subscriptions: string[]
  contactValue: string
  contactType: string
  active:boolean
  showSubscriptions: false
}
