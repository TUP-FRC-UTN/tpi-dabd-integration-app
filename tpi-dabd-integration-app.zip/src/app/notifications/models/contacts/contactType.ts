export interface ContactType {
  id: number
  contactType: string
}
