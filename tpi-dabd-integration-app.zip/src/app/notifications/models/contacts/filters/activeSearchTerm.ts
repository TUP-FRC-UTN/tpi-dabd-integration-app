
export enum ActiveSearchTerm {
    GLOBAL = 'GLOBAL',
    FILTERED = 'FILTERED',
  }
  