export interface Variable {
    key: string;
    value: string;
}