import { Component } from '@angular/core';

@Component({
  selector: 'app-notification-home',
  standalone: true,
  imports: [],
  templateUrl: './notification-home.component.html',
  styleUrl: './notification-home.component.scss'
})
export class NotificationHomeComponent {

}
