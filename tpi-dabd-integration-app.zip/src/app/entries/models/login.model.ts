export interface LoginModel {
  id: number;
  name: string;
  lastName: string;
  docType: string;
  docNumber: number;
  birthDate: string;
}
