import { Component } from '@angular/core';

@Component({
  selector: 'app-entry-home',
  standalone: true,
  imports: [],
  templateUrl: './entry-home.component.html',
  styleUrl: './entry-home.component.scss'
})
export class EntryHomeComponent {

}
